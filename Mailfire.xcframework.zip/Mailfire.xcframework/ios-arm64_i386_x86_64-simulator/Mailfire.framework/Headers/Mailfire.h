//
//  Mailfire.h
//  Mailfire
//
//  Created by Oleksandr Liashko on 8/23/19.
//  Copyright © 2019 Oleksandr Liashko. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Mailfire.
FOUNDATION_EXPORT double MailfireVersionNumber;

//! Project version string for Mailfire.
FOUNDATION_EXPORT const unsigned char MailfireVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mailfire/PublicHeader.h>


